let shopItemsData = [{
    id: "1",
    name: "T-shirt #1",
    price: 33,
 
    img: "Images/img1.jpg"
},{
    id: "2",
    name: "T-shirt #2",
    price: 42,
   
    img: "Images/img2.jpg"
},{
    id: "3",
    name: "T-shirt #3",
    price: 22,
    
    img: "Images/img3.jpg"
},{
    id: "4",
    name: "T-shirt #4",
    price: 27,
 
    img: "Images/img4.jpg"
},{
    id: "5",
    name: "T-shirt #5",
    price: 19,
    
    img: "Images/img5.jpg"
},{
    id: "6",
    name: "T-shirt #6",
    price: 31,
   
    img: "Images/img6.jpg"
},{
    id: "7",
    name: "T-shirt #7",
    price: 34,
   
    img: "Images/img7.jpg"
},{
    id: "8",
    name: "T-shirt #8",
    price: 18,
    
    img: "Images/img8.jpg"
},{
    id: "9",
    name: "T-shirt #9",
    price: 24,
   
    img: "Images/img9.jpg"
},{ 
    id: "10",
    name: "T-shirt #10",
    price: 28,
   
    img: "Images/img10.jpg"
},{
    id: "11",
    name: "T-shirt #11",
    price: 32,
   
    img: "Images/img11.jpg"
},{
    id: "12",
    name: "T-shirt #12",
    price: 20,
   
    img: "Images/img12.jpg"
},{
    id: "13",
    name: "T-shirt #13",
    price: 15,
  
    img: "Images/img13.jpg"
},{
    id: "14",
    name: "T-shirt #14",
    price: 40,
   
    img: "Images/img14.jpg"
},{
    id: "15",
    name: "T-shirt #15",
    price: 28,
   
    img: "Images/img15.jpg"
},{
    id: "16",
    name: "T-shirt #16",
    price: 25,
   
    img: "Images/img16.jpg"
}];