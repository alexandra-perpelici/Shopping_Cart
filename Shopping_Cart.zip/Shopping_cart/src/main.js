
let shop = document.getElementById("shop");


// if we have data in the basket, retrieve it,  if not, it's an empty array
let basket = JSON.parse(localStorage.getItem("data")) || [];
let generateShop =()=>{

    return (shop.innerHTML = shopItemsData.map((x)=>{
        let { id, name, price, desc, img} = x;
        // if the item exists in the local storage, put it in the basket, if not, return an empty array
        let search = basket.find((x) => x.id === id) || [];
        return `
       <div id=product-id-${id} class="item">
           <img width="220" src=${img} alt="">
         <div class="details">
          <h3>${name}</h3>
           <div class="price-quantity">
            <h2>$ ${price} </h2>
            <div class="buttons">
              <i onclick="decrement(${id})" class="bi bi-dash-lg"></i>
              <div id=${id} class="quantity">
              ${localStorage.getItem(id) === null ? 0 : localStorage.getItem(id)}
              </div>
              <i onclick="increment(${id})" class="bi bi-plus-lg"></i>
            </div>
           </div>
          </div>
         </div>
    
       `;
    })
    .join(""));
    
}
 generateShop();

let increment = (id) => {
    let selectedItem = id;
    let search = basket.find((x) => x.id === selectedItem);
  
    if (search === undefined) {
      basket.push({
        id: selectedItem,
        item: 1,
      });
    } else {
      search.item += 1;
      localStorage.setItem(selectedItem, search.item);
    } 
    
     update(selectedItem);
     localStorage.setItem("data", JSON.stringify(basket));

  };


let decrement = (id)=> {
  

    let selectedItem = id;
    let search = basket.find((x) => x.id === selectedItem);
  
    if(search === undefined) return // if we press - having the quantity 0 
    else if (search.item === 0) return 
     else {
      search.item -= 1;
      localStorage.setItem(selectedItem, search.item);
    }  

    update(selectedItem);

    // we put in the basket only the objects that have the item !=0  
    basket = basket.filter((x)=>x.item !== 0);

    // save the basket in the local storage 
    localStorage.setItem("data", JSON.stringify(basket));
   
};



let update  = (id) => {

    selectedItem = id;
    let search = basket.find((x)=>x.id === selectedItem);
    document.getElementById(selectedItem).innerHTML =   search.item;  
    calculation();

};

let calculation = ()=>{
    let cartIcon = document.getElementById("cartAmount");
    cartIcon.innerHTML =  basket.map((x) => x.item).reduce((x, y)=> x + y, 0);
   
};
    calculation();



